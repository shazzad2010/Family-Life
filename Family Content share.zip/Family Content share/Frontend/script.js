document.getElementById('loginForm').addEventListener('submit', async function(e) {
    e.preventDefault();

    const whatsapp = document.getElementById('whatsapp').value;
    const password = document.getElementById('password').value;

    if (whatsapp === '+880...' || password !== '17052011') {
        document.getElementById('message').innerText = 'Invalid WhatsApp Number or Password!';
        return;
    }

    document.getElementById('loginForm').style.display = 'none';
    document.getElementById('fileUploadSection').style.display = 'block';
});

document.getElementById('uploadForm').addEventListener('submit', async function(e) {
    e.preventDefault();

    const file = document.getElementById('file').files[0];

    if (!file) {
        document.getElementById('message').innerText = 'Please select a file.';
        return;
    }

    const formData = new FormData();
    formData.append('file', file);

    try {
        const response = await fetch('http://localhost:5000/upload', {
            method: 'POST',
            body: formData
        });

        const result = await response.json();

        if (result.success) {
            document.getElementById('message').innerText = 'File uploaded successfully!';
            loadUploadedFiles();
        } else {
            document.getElementById('message').innerText = 'Upload failed. Please try again.';
        }
    } catch (error) {
        document.getElementById('message').innerText = 'Upload failed. Please try again.';
    }
});

function loadUploadedFiles() {
    fetch('http://localhost:5000/files')
        .then(response => response.json())
        .then(files => {
            const fileContainer = document.getElementById('uploadedFiles');
            fileContainer.innerHTML = '';
            files.forEach(file => {
                if (file.type.startsWith('image/')) {
                    fileContainer.innerHTML += `<img src="${file.url}" alt="${file.name}" width="200">`;
                } else if (file.type.startsWith('video/')) {
                    fileContainer.innerHTML += `<video controls width="200"><source src="${file.url}" type="${file.type}"></video>`;
                } else {
                    fileContainer.innerHTML += `<a href="${file.url}" download>${file.name}</a>`;
                }
            });
        });
}
